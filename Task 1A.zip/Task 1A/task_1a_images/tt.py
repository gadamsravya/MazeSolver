import numpy as np
import cv2


img=cv2.imread("maze04.jpg")
img=cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
ret,img = cv2.threshold(img,127,255,cv2.THRESH_BINARY)
H,W= img.shape

for h in range(int(H/20)):
	for w in range(int(W/20)):
		print("Cell Number (",h,",",w,"):" )
		flag=0
		for i in range(3+w*20,19+w*20):
			
			img1=img[10+h*20,i]
			if img1==0:
				print("No right")
				flag=1
				break
		if(flag==0):
			print("Can go right ")
		flag=0		
		for i in range(3+h*20,19+h*20):
			
			img1=img[i,10+w*20]
			if img1==0:
				print("No down")
				flag=1
				break
		if(flag==0):
			print("Can go down ")	
			
		flag=0		
		for i in range(17+h*20,h*20-1,-1):
			
			img1=img[i,10+w*20]
			if img1==0:
				print("No Up")
				flag=1
				break
		if(flag==0):
			print("Can go up ")
		flag=0
		for i in range(17+w*20,w*20-1,-1):
			
			img1=img[10+h*20,i]
			if img1==0:
				print("No left")
				flag=1
				break
		if(flag==0):
			print("Can go left ")
			
img1=img
cv2.imshow("Image1",img1)
cv2.waitKey(0)
cv2.destroyAllWindows()
