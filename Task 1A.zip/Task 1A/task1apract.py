import numpy as np
import cv2



def convertToBinary(imgPath):
	img=cv2.imread(imgPath);
	img=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
	ret,img2=cv2.threshold(img,128,255,type=cv2.THRESH_BINARY)
	#cv2.imshow('IMAGE',img2)
	#cv2.waitKey(0)
	#cv2.destroyAllWindows()
	return img2

def isNeighbour(img, point, prosNeigh, hI, wI, direction):
	sizeOfImg=img.shape
	nHC=sizeOfImg[0]/hI
	nWC=sizeOfImg[1]/wI
	

	if(prosNeigh[0]<0 or prosNeigh[1]<0 or prosNeigh[0]>=nHC or prosNeigh[1]>=nWC):
		return False
		
	if(direction=='up'):
		L=list(range(hI*point[1],int(hI*point[1]+(hI/5))))
		for i in L:
			if(np.sum(img[i, point[0]*wI:point[0]*wI+wI]) <= wI*255/2):
				return False
				
		L=list(range(int(hI*point[1]-(hI/5)),hI*point[1]))
		#print(img[int(hI*point[1]-(hI/5)):hI*point[1],prosNeigh[0]*wI:prosNeigh[0]*wI+wI])
		for i in L:
			if(np.sum(img[i, prosNeigh[0]*wI:prosNeigh[0]*wI+wI]) <= wI*255/2):
				return False
	
	elif(direction=='down'):
		L=list(range(hI*prosNeigh[1],int(hI*prosNeigh[1]+(hI/5))))
		for i in L:
			if(np.sum(img[i, point[0]*wI:point[0]*wI+wI]) <= wI*255/2):
				return False
				
		L=list(range(int(hI*prosNeigh[1]-(hI/5)),hI*prosNeigh[1]))
		for i in L:
			if(np.sum(img[i, prosNeigh[0]*wI:prosNeigh[0]*wI+wI]) <= wI*255/2):
				return False
				
	elif(direction=='right'):
		#print("in right")
		#print(img[prosNeigh[0]*hI:prosNeigh[0]*hI+hI, wI*prosNeigh[0]:int(wI*prosNeigh[0]+(wI/5))])
		L=list(range(wI*prosNeigh[0],int(wI*prosNeigh[0]+(wI/5))))
		for i in L:
			if(np.sum(img[prosNeigh[1]*hI:prosNeigh[1]*hI+hI , i]) <= hI*255/2):
				
				return False
				
		L=list(range(int(wI*prosNeigh[0]-(wI/5)),wI*prosNeigh[0]))
		
		for i in L:
			if(np.sum(img[prosNeigh[1]*hI:prosNeigh[1]*hI+hI , i]) <= hI*255/2):
				return False
				
	elif(direction=='left'):
		L=list(range(wI*point[0],int(wI*point[0]+(wI/5))))
		for i in L:
			if(np.sum(img[point[1]*hI:point[1]*hI+hI , i]) <= hI*255/2):
				return False
				
		L=list(range(int(wI*point[0]-(wI/5)),wI*point[0]))
		for i in L:
			if(np.sum(img[point[1]*hI:point[1]*hI+hI , i]) <= hI*255/2):
				return False
	
	return True	
	
def shortestPath(imgPath, startPt, endPt, noOfCellsInHeight, noOfCellsInWidth):
	
	img=convertToBinary(imgPath)
	sizeOfImg=img.shape
	
	
	hI=int(sizeOfImg[0]/noOfCellsInHeight)
	wI=int(sizeOfImg[1]/noOfCellsInWidth)
	
	queue=[]
	queue.append([startPt])
	
	finalPath=[]
	#c=0
	while(len(queue)!=0):
		path=queue.pop(0)
		
		if(len(path)>1):
			pt=path[-1]
			previousPt=path[-2]
		else:
			pt=path[0]
			previousPt=np.array([-1,-1])
			
		if(isNeighbour(img,pt,np.add(pt,np.array([0,1])),hI,wI,'down') and not(np.array_equal(np.add(pt,np.array([0,1])),previousPt))):
			newPt=np.add(pt,np.array([0,1]))
			newPath=path.copy()
			newPath.append(newPt)
			queue.append(newPath)
			if(np.array_equal(newPt,endPt)):
				finalPath=newPath
				break
		#print('path:')
		#print(path)
		if(isNeighbour(img,pt,np.add(pt,np.array([1,0])),hI,wI,'right') and not(np.array_equal(np.add(pt,np.array([1,0])),previousPt))):
			
			newPt=np.add(pt,np.array([1,0]))
			#print(path)
			newPath=path.copy()
			newPath.append(newPt)
			
			#print(newPath)
			queue.append(newPath)
			#print(queue)
			if(np.array_equal(newPt,endPt)):
				finalPath=newPath
				break
		#print('path:')
		#print(path)		
		if(isNeighbour(img,pt,np.add(pt,np.array([0,-1])),hI,wI,'up') and not(np.array_equal(np.add(pt,np.array([0,-1])),previousPt))):
			newPt=np.add(pt,np.array([0,-1]))
			newPath=path.copy()
			newPath.append(newPt)
			queue.append(newPath)
			if(np.array_equal(newPt,endPt)):
				finalPath=newPath
				break
		#print('path:')
		#print(path)		
		if(isNeighbour(img,pt,np.add(pt,np.array([-1,0])),hI,wI,'left') and not(np.array_equal(np.add(pt,np.array([-1,0])),previousPt))):
			newPt=np.add(pt,np.array([-1,0]))
			newPath=path.copy()
			newPath.append(newPt)
			queue.append(newPath)
			if(np.array_equal(newPt,endPt)):
				finalPath=newPath
				break
		#print('path:')
		#print(path)
		#print(queue)		
		#c=c+1
	final=[tuple(item) for item in finalPath]
	#final=[item[::-1] for item in final1]			
	return final
				
def showPath(img, path, widthOfCell, heightOfCell):
	for i in path:
		img[heightOfCell*i[1]+int(heightOfCell/5):(heightOfCell)*(i[1]+1)-int(heightOfCell/5), widthOfCell*i[0]+int(widthOfCell/5):(widthOfCell)*(i[0]+1)-int(widthOfCell/5)]=128
	
	cv2.imshow('PATH', img)
	cv2.waitKey(0)
	cv2.destroyAllWindows()
		
x=shortestPath('task_1a_images/maze03.jpg',np.array([0,0]),np.array([19,19]),20,20)
img=convertToBinary('task_1a_images/maze03.jpg')
sizeOfImg=img.shape
#print(sizeOfImg)
hI=int(sizeOfImg[0]/20)
wI=int(sizeOfImg[1]/20)
#x=isNeighbour(img,np.array([1,0]), np.array([0,0]), hI, wI, 'left')
print(x)
showPath(img, x, hI, wI)		
	
